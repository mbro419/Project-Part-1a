import java.util.Scanner;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
/**
 * Prog01_aOrderedList is a class that manages a file that contains a list of cars and their descriptors. The list of cars from the input file are copied to an output file created by the user and then outputted by the program
 *
 * CSC 1351 Programming Project Part 1
 * Section 2
 *
 * @author Madelaine Brown
 * @since 03/17/2024
 */
public class Prog01_aOrderedList {
    /**
     * Main method to run the program
     *
     * CSC 1351 Programming Project Part 1
     * Section 2
     *
     * @author Madelaine Brown
     * @since 03/17/2024
     *  
     */
	public static void main(String[] args) {
       aOrderedList<Car> orderedList = new aOrderedList<>();//Initializes the orderedt list

        try (Scanner scanner = getInputFile("Enter input filename: ")) { //Takes in the name of the input file
            while (scanner.hasNextLine()) {
                String line = scanner.nextLine();
                String[] parts = line.split(",");//Indicates how many parts are in each car object line and splits the words up based on commas (A/D, Make, Year, Price)
                if (parts.length >= 1) {
                    String operation = parts[0].trim(); //Checks whether the car descriptor begins with A or D
                    if (operation.equals("A")) { //Operation to add a car
                        if (parts.length == 4) {//The length of the car data (A/D, Make, Year, Price)
                            String make = parts[1].trim();
                            int year = Integer.parseInt(parts[2].trim());
                            int price = Integer.parseInt(parts[3].trim());
                            Car newCar = new Car(make, year, price); //Each individual car object
                            orderedList.add(newCar);
                        } else {
                            System.out.println("Invalid add operation: " + line); //The addition operation is invalid
                        }
                    } else if (operation.equals("D")) { //Operation to delete a car
                        if (parts.length == 3) {
                            String make = parts[1].trim(); 
                            int year = Integer.parseInt(parts[2].trim());
                            Car carToRemove = new Car(make, year, 0); //Represents the car that needs to be removed
                            orderedList.remove(carToRemove);
                        } else {
                            System.out.println("Invalid delete operation: " + line); //The deletion operation is invalid
                        }
                    } 
                }
            }
        } catch (FileNotFoundException e) { //Input file not found 
            System.out.println("File does not exist.");
            return; //Exits the program if the input file does not exist
        }
        try {
            String outputFileName = getOutputFile("Enter output filename: ", orderedList); //Copies the content of the array to an output file
            PrintWriter writer = new PrintWriter(new File(outputFileName)); //Represents the file that the contents are being outputted from
           
            writer.printf("Number of cars: %d%n", orderedList.size()); //Outputs the number of cars

            for (int i = 0; i < orderedList.size(); i++) { //Prints the formatted content of the cars in the file
                Car car = orderedList.get(i); //Represents each car in the list
                writer.println(); 
                writer.printf("Make:\t %-4s%n", car.getMake());
                writer.printf("Year:\t %-6d%n", car.getYear());
                writer.printf("Price:\t $%,d%n", car.getPrice());
            }
            writer.close();

            
            Scanner reader = new Scanner(new File(outputFileName)); //Checks if there is another line to be read by the output file (I think this is correct but I don't remember what exactly this does but if I remove it the program will not execute correctly)
            while (reader.hasNextLine()) {
                String line = reader.nextLine();
                System.out.println(line);
            }
            reader.close();
        } catch (FileNotFoundException e) {//Output file can either not be created or written over
            System.out.println("Output file cannot be created. Program execution canceled.");
        }
    }

    /**
     * Prompts the user for the input file name and returns a Scanner to read from the file.
     * Continues to prompt the user until a valid file name is provided or the user cancels.
     *
     * CSC 1351 Programming Project Part 1
     * Section 2
     *
     * @author Madelaine Brown
     * @since 03/17/2024
     * 
     */
    public static Scanner getInputFile(String userPrompt) throws FileNotFoundException {
        Scanner scanner = new Scanner(System.in);
        String inputFileName; //Represents the input file

        while (true) { //Checks if the input file exists (inputfile.txt)
            System.out.print(userPrompt);
            inputFileName = scanner.nextLine();
            File inputFile = new File(inputFileName);

            if (!inputFile.exists()) {
                System.out.println("File specified <" + inputFileName + "> does not exist.");
                System.out.print("Would you like to continue? <Y/N> ");
                String choice;
                do {
                    choice = scanner.nextLine().toUpperCase(); //The Y or N input of the user
                    if (choice.equals("N")) { //If the user enters N, the exception is thrown and the program ends
                        scanner.close();
                        throw new FileNotFoundException(); 
                    	} 
                    else if (!choice.equals("Y")) { //If the user enters Y, the user will be prompted for another file name
                        System.out.print("Please enter either 'Y' or 'N': ");
                    	}
                } while (!choice.equals("Y") && !choice.equals("N")); //Asks the user for Y or N if they enter something else
            } 		
            		else {
            			return new Scanner(inputFile);
            		}
        }
    }

    /**
     * Takes in the output file name from the user and copies the contents from the ordered list onto it
     *
     * CSC 1351 Programming Project Part 1
     * Section 2
     *
     * @author Madelaine Brown
     * @since 03/17/2024
     * 
     */
    public static String getOutputFile(String userPrompt, aOrderedList<Car> orderedList) throws FileNotFoundException {
        Scanner scanner = new Scanner(System.in);
        String outputFileName;

        do {
            System.out.print(userPrompt);
            outputFileName = scanner.nextLine();
            File outputFile = new File(outputFileName);

            if (outputFile.exists()) {//If the file already exists then the program asks the user if they would like to overwrite the file and continue
               System.out.print("Overwrite existing file " + outputFileName + "? <Y/N> ");
                String choice;
                do {
                    choice = scanner.nextLine().toUpperCase(); //The Y or N input of the user
                    if (choice.equals("N")) { //If the user enters N, the exception is thrown and the program ends
                        scanner.close();
                    	} 
                    else if (!choice.equals("Y")) { //If the user enters Y, the user will be prompted for another file name
                        System.out.print("Please enter either 'Y' or 'N': ");
                    	}
                } while (!choice.equals("Y") && !choice.equals("N"));
                scanner.close();
                return outputFileName; 
        } 
            
            
    }
        while (true); // Repeat until a valid output file is created
    	}
 }
